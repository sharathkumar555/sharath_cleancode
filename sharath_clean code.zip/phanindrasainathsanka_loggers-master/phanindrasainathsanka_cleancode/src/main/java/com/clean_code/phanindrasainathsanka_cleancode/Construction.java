package com.clean_code.phanindrasainathsanka_cleancode;
public class Construction {
	public int construct(int t,int m)
	{
		int total_cost=t*m;
		return total_cost;
	}
}